﻿var userName;
var questionCount = 0;
var totalPoints = 0;
var rowCount = 0;

var Images;
var Answers = "";

$(document).ready(function () {
    $('#startPage').show();
    $('#gamePage').hide();
    $('#resultPage').hide();
});

function startGame()
{
    if ($("#txtName").val() == "") {
        alert("PLease enter your name to start a game!");
        $('#startPage').show();
        $('#gamePage').hide();
        $('#resultPage').hide();
    } else {
        $('#startPage').hide();
        $('#gamePage').show();
        $('#resultPage').hide();

        userName = $("#txtName").val();
        questionCount = 1;
        totalPoints = 0;
        rowCount = 0;

        $('#usrNameValue').text(userName);
        selectGameDetails();
    }

}

function selectGameDetails() {
    $.ajax({
        url: '/api/WordPuzzle',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            Images = data;
            if (Images.length > 0) {
                $('#image1Value').attr('src', 'Images/' + Images[rowCount].Image1);
                $('#image2Value').attr('src', 'Images/' + Images[rowCount].Image2);
                $('#image3Value').attr('src', 'Images/' + Images[rowCount].Image3);
                $('#image4Value').attr('src', 'Images/' + Images[rowCount].Image4);
            }

            $('#questionCountValue').val(questionCount);
            $('#totalPointsValue').val(totalPoints);

            Answers = Images[rowCount].Answer;
        }
    });
}

function checkAnswer()
{
    if ($('#txtAnswer').val() == "")
    {
        alert('Please enter some answer');
        return;
    }

    if ($('#txtAnswer').val().toLowerCase() === Answers.toLowerCase()) {
        alert("Cool :) Correct answer! +20 points to your score!");
        totalPoints = totalPoints + 20;
        $('totalPointsValue').val(totalPoints);
    }
    else {
        alert("Oops :( Wrong answer... -10 points from your score.. ;(");
        totalPoints = totalPoints - 10;
        $('totalPointsValue').val(totalPoints);
    }

    $('#txtAnswer').val("");

    if (questionCount === 5) {
        if (totalPoints >= 100) {
            $('#result').text("Wow! You have won the Game. Good Job " + userName);
            $('#resultImage').attr('src', 'Images/won.png');

            $('#startPage').hide();
            $('#gamePage').hide();
            $('#resultPage').show();
        }
        else {
            $('#result').text("Sorry " + userName + " You lose the game. Your Total points are " + totalPoints + " out of 100 points");
            $('#resultImage').attr('src', 'Images/lose.png');
        }

        $('#startPage').hide();
        $('#gamePage').hide();
        $('#resultPage').show();

        return;
    }
    else {
        questionCount = questionCount + 1;
        rowCount = rowCount + 1;

        $("#image1Value").attr('src', 'Images/' + Images[rowCount].Image1);
        $("#image2Value").attr('src', 'Images/' + Images[rowCount].Image2);
        $("#image3Value").attr('src', 'Images/' + Images[rowCount].Image3);
        $("#image4Value").attr('src', 'Images/' + Images[rowCount].Image4);

        $('#questionCountValue').val(questionCount);
        $('#totalPointsValue').val(totalPoints);

        Answers = Images[rowCount].Answer;
    }
}

function startNewGame()
{
    usrName = "";
    questionCount = 1;
    totalPoints = 0;
    rowCount = 0;

    $('#txtName').val("");
    $('#startPage').show();
    $('#gamePage').hide();
    $('#resultPage').hide();
}