﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WordPuzzleGame.Models
{
    public class WordPuzzle
    {
        public string WornName { get; set; }
        public string Image1 { get; set; }
        public string Image2 { get; set; }
        public string Image3 { get; set; }
        public string Image4 { get; set; }
        public string Answer { get; set; }
    }
}