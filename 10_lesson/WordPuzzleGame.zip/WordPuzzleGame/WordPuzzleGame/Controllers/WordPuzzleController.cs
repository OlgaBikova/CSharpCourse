﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WordPuzzleGame.Models;

namespace WordPuzzleGame.Controllers
{
    public class WordPuzzleController : ApiController
    {
        public IEnumerable<WordPuzzle> Get()
        {
            var wordPuzzleList = new List<WordPuzzle>();

            string connestionString = "Data Source=localhost\\SQLEXPRESS; Initial catalog=test; Integrated Security=true";

            using (SqlConnection connection = new SqlConnection(connestionString))
            {
                connection.Open();

                string queryString = "SELECT image1, image2, image3, image4, answer FROM dbo.wordDetails";

                SqlCommand command = new SqlCommand(queryString, connection);

                var reader = command.ExecuteReader();

                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var wordPuzzle = new WordPuzzle()
                        {
                            Image1 = reader["image1"].ToString(),
                            Image2 = reader["image2"].ToString(),
                            Image3 = reader["image3"].ToString(),
                            Image4 = reader["image4"].ToString(),
                            Answer = reader["answer"].ToString()
                        };

                        wordPuzzleList.Add(wordPuzzle);
                    }
                }
            }

            wordPuzzleList = wordPuzzleList.OrderBy(x => Guid.NewGuid()).Take(5).ToList();

            return wordPuzzleList;
        }
    }
}
